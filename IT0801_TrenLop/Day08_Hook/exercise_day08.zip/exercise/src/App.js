import {useState, useEffect} from 'react';



function App(props) {

  let [selectedCar, setSelectedCar] = useState("0");
  let [valueSelectedCar, setValueSelectedCar] = useState("");

  let [selectedColor, setSelectedColor] = useState ("0");
  let [valueSelectedColor, setValueSelectedColor] = useState ("");

  const choiceCar = e => {
    setSelectedCar(e.target.value);
  }

  const choiceColor = e => {
    setSelectedColor(e.target.value);
  }

  useEffect(() => {
    switch (selectedCar){
      case "0":
        setValueSelectedCar("Aston Martin");
        break;
      case "1":
        setValueSelectedCar("Bentley");
        break;
      case "2":
        setValueSelectedCar("Lamborghini");
        break;
      case "3":
        setValueSelectedCar("Ferrari");
        break;
      case "4":
        setValueSelectedCar("Porsche");
        break;
      case "5":
        setValueSelectedCar("VinFast");
        break;
        default:     
    }
  }, [selectedCar]);

  useEffect(() => {
    switch (selectedColor) {
      case "0":
        setValueSelectedColor("Red");
        break;
      case "1":
        setValueSelectedColor("Blue");
        break;
      case "2":
        setValueSelectedColor("Yellow");
        break;
      case "3":
        setValueSelectedColor("Black");
        break;
      case "4":
        setValueSelectedColor("White");
        break;
      case "5":
        setValueSelectedColor("Orange");
        break;   
      default:      
    }
  }, [selectedColor]);

  return(
    <div className='container'>
      <div className = "car">
        <h3>Car</h3>
        <select onChange = {e => {choiceCar(e)}}>
          <option value = "0">Aston Martin</option>
          <option value = "1">Bentley</option>
          <option value = "2">Lamborghini</option>
          <option value = "3">Ferrari</option>
          <option value = "4">Porsche</option>
          <option value = "5">VinFast</option>
        </select>
      </div>
      <div className = "color">
        <h3>Color</h3>
        <select onChange = {e => {choiceColor(e)}}>
          <option value = "0">Red</option>
          <option value = "1">Blue</option>
          <option value = "2">Yellow</option>
          <option value = "3">Black</option>
          <option value = "4">White</option>
          <option value = "5">Orange</option>
        </select>
      </div>
      <h2>Your selected: Car: {valueSelectedCar}, Color: {valueSelectedColor}</h2>
      

    </div>
  )
}

export default App;
